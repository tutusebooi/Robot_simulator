user_input = input("enter: ").lower()
print(user_input)
