user = int(input(""))
results = 300000000**2 * user
print(results)

